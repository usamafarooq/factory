<!-- /.Navbar  Static Side -->
<div class="control-sidebar-bg"></div>
<!-- Page Content -->
<div id="page-wrapper">
    <!-- main content -->
    <div class="content">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="header-icon">
                <i class="pe-7s-note2"></i>
            </div>
            <div class="header-title">
                <h1>Add Production plan</h1>
                <small></small>
                <ol class="breadcrumb">
                    <li><a href="index.html"><i class="pe-7s-home"></i> Home</a></li>
                    <li class="active">Add Production plan</li>
                </ol>
            </div>
        </div>
        <!-- /. Content Header (Page header) -->

        <form method="post" action="" enctype="multipart/form-data">

            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-bd ">
                        <div class="panel-heading">
                            <div class="panel-title">
                                <h4>Add Production plan</h4>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div class="add-div row">
                                <div class="form-group row">

                                    <div class="form-group col-lg-6">
                                        <label for="example-text-input" class="col-sm-3 col-form-label">Type</label>
                                        <div class="col-sm-9">
                                            <select class="form-control" name="type[]">
                                                <option>Select Type</option>
                                                <?php 
                                                  foreach ($flows as $f) {
                                                    echo '<option value="'.$f['id'].'">'.$f['Name'].'</option>';
                                                  }
                                                ?>
                                            </select>
                                        </div>

                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="example-text-input" class="col-sm-3 col-form-label">Machine</label>
                                        <div class="col-sm-9">
                                            <select class="form-control sel" name="machine[]">
                                                <option>Select Machine</option>
                                            </select>
                                        </div>

                                    </div>

                                </div>
                                <div class="form-group row">

                                    <div class="form-group col-lg-6">
                                        <label for="example-text-input" class="col-sm-3 col-form-label">Priority</label>
                                        <div class="col-sm-9">
                                            <select class="form-control" name="priority[]">
                                              <option>Select Priority</option>
                                              <option value="Hi">Hi</option>
                                              <option value="Low">Low</option>
                                            </select>
                                        </div>

                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="example-text-input" class="col-sm-3 col-form-label">Parent</label>
                                        <div class="col-sm-9">
                                            <select class="form-control" name="parent[]">
                                                <option>Select Parent</option>
                                                <?php 
                                                  foreach ($flows as $f) {
                                                    echo '<option value="'.$f['id'].'">'.$f['Name'].'</option>';
                                                  }
                                                ?>
                                            </select>
                                        </div>

                                    </div>

                                </div>
                                <div class="form-group row">

                                    <div class="form-group col-lg-6">
                                        <label for="example-text-input" class="col-sm-3 col-form-label">Start Date</label>
                                        <div class="col-sm-9">
                                            <input class="form-control" name="start_date[]" type="date"  id="example-text-input" placeholder="">
                                        </div>

                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="example-text-input" class="col-sm-3 col-form-label">End Date</label>
                                        <div class="col-sm-9">
                                            <input class="form-control" name="end_date[]" type="date" value="" id="example-text-input" placeholder="">
                                        </div>

                                    </div>

                                </div>
                                <div class="form-group row">
                                    <div class="col-lg-2 delet pull-right">
                                        <button type="button" class="add-sub btn btn-success ">Add More</button>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">

                                <div class="col-sm-12">
                                    <button type="submit" class="btn btn-primary pull-right">Add</button>
                                </div>
                            </div>
                            <button type="button" style="display: none;" class="btn btn-info btn-lg click-btn" data-toggle="modal" data-target="#dialog-modal">Open Modal</button>

<div class="modal fade" id="dialog-modal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <div class=row>
              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 statistic-box  border"  style="  background-color: #fcfdff ">
                  <h5 style="color: black;"><strong>1 : Cutting Machine Detail</strong></h5>
                     <div id="chart_div3"></div>
              </div>
          </div>  
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
                        </div>
                    </div>
                </div>
        </form>
        </div>
    </div>

</div>

<!-- /.main content -->
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

  <!-- start chart 1 -->
<script type="text/javascript">
  var values = []
    google.charts.load('current', {'packages':['gantt']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart(values) {
      //console.log(values)
      var data = new google.visualization.DataTable();
      /*data.addColumn('string', 'Task ID');
      data.addColumn('string', 'Task Name');
      data.addColumn('date', 'Start Date');
      data.addColumn('date', 'End Date');
      data.addColumn('number', 'Duration');
      data.addColumn('number', 'Percent Complete');
      data.addColumn('string', 'Dependencies');*/
      data.addColumn('string', 'Task ID');
      data.addColumn('string', 'Task Name');
      data.addColumn('date', 'Start Date');
      data.addColumn('date', 'End Date');
      data.addColumn('number', 'Duration');
      data.addColumn('number', 'Percent Complete')
      data.addColumn('string', 'Dependencies');
      data.addRows(values.length);
      for (var i = 0; i < values.length; i++) {
        data.setCell(i, 0, values[i].id);
        data.setCell(i, 1, values[i].Job_Description);
        data.setCell(i, 2, new Date(values[i].start_date));
        data.setCell(i, 3, new Date(values[i].end_date));
        data.setCell(i, 4, null);
        data.setCell(i, 5, 0);
        data.setCell(i, 6, null);
      }
      /*data.addRows([
        ['2014Spring', 'Job 1',
         new Date(2015, 2, 22), new Date(2015, 5, 20), null, 90, null],
        ['2014Summer', 'Job 2',
         new Date(2014, 5, 21), new Date(2014, 8, 20), null, 100, null],
        ['2014Autumn', 'Job 3',
         new Date(2014, 8, 21), new Date(2014, 11, 20), null, 100, null],
        ['2014Winter', 'Job 4',
         new Date(2014, 11, 21), new Date(2015, 2, 21), null, 100, null],
        ['2015Spring', 'Job 5',
         new Date(2015, 2, 22), new Date(2015, 5, 20), null, 50, null],
        ['2015Summer', 'Job 6',
         new Date(2015, 5, 21), new Date(2015, 8, 20), null, 0, null]
      ]);*/

      var options = {
        height: 190,
        width: 550,
        gantt: {
          trackHeight: 30
        }
      };

      var chart = new google.visualization.Gantt(document.getElementById('chart_div3'));
      chart.clearChart(); 
      chart.draw(data, options);
    }
</script>
<script type="text/javascript">
    $("body").on("click",".add-sub",function(){
        var html = $(".add-div").first().clone();
        $(html).find(".delet").html("<a class='btn btn-danger remove'><i class='fa fa-trash-o' aria-hidden='true'></i> </a> "+' <a class="btn btn-success add-sub"><strong> + </strong> </a>');
        $(".add-div").last().after(html);
        $(".add-div").last().find('input,select').val('')
        get_machines()
    });
    $("body").on("click",".remove",function(){
        $(this).parents(".add-div").remove();
    });
    function get_machines() {
      $('[name="type[]"]').change(function() {
        var val = $(this).val()
        $.ajax({
          url: "<?php echo base_url('production_plan/get_machines/') ?>"+val,
          type: 'GET',
          dataType: 'json', // added data type
          success: function(res) {
            $('[name="machine[]"] option').not('[name="machine[]"] option:first-child').remove()
            for (var i = 0; i < res.length; i++) {
              $('[name="machine[]"]').append('<option value="'+res[i].id+'">'+res[i].machine_Name+'</option>')
            }
          }
        });
      })
      $('.sel').change(function () {
        var val = $(this).val()
        $.ajax({
          url: "<?php echo base_url('production_plan/get_machine_detail/') ?>"+val,
          type: 'GET',
          dataType: 'json', // added data type
          success: function(res) {
            $('.click-btn').click();
            drawChart(res)
          }
        });
      });
    }
    get_machines()
</script>
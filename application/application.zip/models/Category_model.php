<?php
		    class Category_model extends MY_Model{

		    	}
<?php
		    class Flows_model extends MY_Model{

		    	}
<?php
		    class Feature_model extends MY_Model{

		    	}
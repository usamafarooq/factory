<?php
		    class Vendor_model extends MY_Model{

		    	}
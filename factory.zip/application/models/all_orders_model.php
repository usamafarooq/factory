<?php
		    class all_orders_model extends MY_Model{

		    	}
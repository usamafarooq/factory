<?php
		    class Clients_model extends MY_Model{

		    	}
<?php
		    class Orders_model extends MY_Model{

		    	}
<?php
		    class Sub_store_model extends MY_Model{

		    	}
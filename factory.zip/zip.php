<?php 
system('unzip factory.zip');
?>